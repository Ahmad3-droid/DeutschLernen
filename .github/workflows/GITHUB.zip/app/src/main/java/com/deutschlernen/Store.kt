package com.deutschlernen

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.staticCompositionLocalOf

data class Cat(val key: String, val icon: String, val title: String)
data class SavedItem(val cat: String, val de: String, val ar: String)

val CATS = listOf(
    Cat("liquid", "💧", "سوائل"),
    Cat("food", "🍎", "أكل"),
    Cat("object", "🪑", "جماد"),
    Cat("animal", "🐾", "حيوان"),
)

/** تخزين محلي للكلمات المحفوظة (SharedPreferences) دون إنترنت. */
class SavedStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("saved", Context.MODE_PRIVATE)
    val items = mutableStateListOf<SavedItem>()

    init {
        val raw = prefs.getString("data", null)
        if (raw == null) {
            try {
                ctx.assets.open("saved_defaults.txt").bufferedReader().readLines()
                    .filter { it.isNotBlank() }
                    .forEach {
                        val p = it.split(";")
                        if (p.size >= 3) items.add(SavedItem(p[0].trim(), p[1].trim(), p[2].trim()))
                    }
            } catch (e: Exception) { }
            persist()
        } else {
            raw.lines().filter { it.isNotBlank() }.forEach {
                val p = it.split(";")
                if (p.size >= 3) items.add(SavedItem(p[0], p[1], p[2]))
            }
        }
    }

    private fun clean(s: String) = s.replace(";", " ").replace("\n", " ").trim()

    private fun persist() {
        prefs.edit().putString("data", items.joinToString("\n") { "${it.cat};${it.de};${it.ar}" }).apply()
    }

    fun add(cat: String, de: String, ar: String): Boolean {
        val d = clean(de)
        val a = clean(ar)
        if (d.isEmpty() || items.any { it.cat == cat && it.de.equals(d, true) }) return false
        items.add(SavedItem(cat, d, a))
        persist()
        return true
    }

    fun remove(item: SavedItem) {
        items.remove(item)
        persist()
    }
}

val LocalStore = staticCompositionLocalOf<SavedStore> { error("SavedStore not provided") }
