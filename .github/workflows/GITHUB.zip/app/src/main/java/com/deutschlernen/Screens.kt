@file:OptIn(ExperimentalMaterial3Api::class)

package com.deutschlernen

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

val Ltr = TextStyle(textDirection = TextDirection.Ltr)
private val Green = Color(0xFF4CAF50)
private val Red = Color(0xFFEF5350)

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("← رجوع") }
        Spacer(Modifier.width(8.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun SpeedBar(speed: Float, onSpeed: (Float) -> Unit) {
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("السرعة:", color = Color.Gray)
        listOf(0.5f, 0.75f, 1f, 1.25f).forEach { v ->
            FilterChip(selected = speed == v, onClick = { onSpeed(v) }, label = { Text("${v}x") })
        }
    }
}

@Composable
fun SpeakButton(text: String, speaker: Speaker, speed: Float) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val scale = remember { Animatable(1f) }
    Button(
        onClick = {
            if (!speaker.speak(text, speed))
                Toast.makeText(ctx, "ثبّت صوت اللغة الألمانية من إعدادات تحويل النص إلى كلام", Toast.LENGTH_LONG).show()
            scope.launch { scale.animateTo(1.3f, tween(120)); scale.animateTo(1f, spring()) }
        },
        modifier = Modifier.scale(scale.value)
    ) { Text("🔊  استمع") }
}

// ---------------------------------------------------------------- Level screen

@Composable
fun SubScreen(
    code: String, color: Color, speaker: Speaker, speed: Float,
    onSpeed: (Float) -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val words = remember(code) { loadWords(ctx, code) }
    var mode by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TopBar("المستوى $code", onBack)
        SpeedBar(speed, onSpeed)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("📇 بطاقات", "⌨️ كتابة").forEachIndexed { i, t ->
                FilterChip(selected = mode == i, onClick = { mode = i }, label = { Text(t) })
            }
        }
        Spacer(Modifier.height(12.dp))
        if (words.isEmpty()) {
            Text("لا توجد كلمات بعد", Modifier.padding(16.dp))
        } else {
            Crossfade(mode, label = "mode") { m ->
                if (m == 0) Cards(words, speaker, speed, color) else Writing(words, speaker, speed, color)
            }
        }
    }
}

@Composable
fun FlipCard(w: Word, speaker: Speaker, speed: Float, color: Color) {
    var flipped by remember { mutableStateOf(false) }
    val rot by androidx.compose.animation.core.animateFloatAsState(if (flipped) 180f else 0f, tween(500), label = "flip")
    val density = LocalDensity.current.density
    Box(
        Modifier.fillMaxWidth().height(240.dp)
            .graphicsLayer { rotationY = rot; cameraDistance = 12f * density }
            .clip(RoundedCornerShape(28.dp))
            .background(color.copy(alpha = 0.2f))
            .clickable { flipped = !flipped },
        contentAlignment = Alignment.Center
    ) {
        if (rot <= 90f) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(w.de, style = Ltr.copy(fontSize = 34.sp, fontWeight = FontWeight.Bold, color = color))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { SpeakButton(w.de, speaker, speed); SaveButton(w) }
                Text("اضغط لقلب البطاقة", color = Color.Gray, fontSize = 12.sp)
            }
        } else {
            Column(
                Modifier.graphicsLayer { rotationY = 180f }.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(w.ar, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                if (w.ex.isNotBlank()) {
                    Text(w.ex, style = Ltr.copy(fontSize = 16.sp, color = Color.LightGray, textAlign = TextAlign.Center))
                    SpeakButton(w.ex, speaker, speed)
                }
            }
        }
    }
}

@Composable
fun Cards(words: List<Word>, speaker: Speaker, speed: Float, color: Color) {
    var i by remember { mutableIntStateOf(0) }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        LinearProgressIndicator(progress = { (i + 1f) / words.size }, Modifier.fillMaxWidth(), color = color)
        AnimatedContent(
            targetState = i,
            transitionSpec = { (slideInHorizontally(tween(300)) { it } + fadeIn()) togetherWith (slideOutHorizontally(tween(300)) { -it } + fadeOut()) },
            label = "card"
        ) { idx -> FlipCard(words[idx], speaker, speed, color) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { if (i > 0) i-- }) { Text("السابق") }
            Text("${i + 1} / ${words.size}")
            Button(onClick = { if (i < words.size - 1) i++ }) { Text("التالي") }
        }
    }
}

@Composable
fun Writing(words: List<Word>, speaker: Speaker, speed: Float, color: Color) {
    var i by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var ok by remember { mutableStateOf<Boolean?>(null) }
    var attempt by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    val shake = remember { Animatable(0f) }
    LaunchedEffect(attempt) {
        if (attempt > 0 && ok == false) {
            repeat(3) { shake.animateTo(14f, tween(50)); shake.animateTo(-14f, tween(50)) }
            shake.animateTo(0f, tween(50))
        }
    }
    val w = words[i]
    Column(
        Modifier.fillMaxWidth().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("النقاط: $score", color = color)
        Text("اكتب بالألمانية:", color = Color.Gray)
        Text(w.ar, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        SpeakButton(w.de, speaker, speed)
        OutlinedTextField(
            value = input, onValueChange = { input = it; ok = null },
            modifier = Modifier.fillMaxWidth().offset(x = shake.value.dp),
            singleLine = true, textStyle = Ltr.copy(fontSize = 20.sp),
            label = { Text("Deutsch") }
        )
        AnimatedVisibility(ok != null) {
            if (ok == true) Text("✅ Richtig! صحيح", color = Green, fontSize = 20.sp)
            else Text("❌ الصحيح: ${w.de}", color = Red, fontSize = 18.sp, style = Ltr.copy(color = Red))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = {
                val right = input.trim() == w.de
                ok = right; attempt++
                if (right) { score++; speaker.speak(w.de, speed) }
            }) { Text("تحقق") }
            OutlinedButton(onClick = { i = (i + 1) % words.size; input = ""; ok = null }) { Text("التالي") }
        }
        Text("ملاحظة: اكتب الأداة (der/die/das) والحرف الكبير للأسماء", color = Color.Gray, fontSize = 12.sp)
    }
}

// ---------------------------------------------------------------- Alphabet

@Composable
fun AlphabetScreen(speaker: Speaker, speed: Float, onSpeed: (Float) -> Unit, onBack: () -> Unit) {
    var sel by remember { mutableStateOf(LETTERS[0]) }
    LazyVerticalGrid(
        GridCells.Fixed(4), Modifier.fillMaxSize().padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { TopBar("الأبجدية الألمانية", onBack) }
        item(span = { GridItemSpan(maxLineSpan) }) { SpeedBar(speed, onSpeed) }
        item(span = { GridItemSpan(maxLineSpan) }) {
            AnimatedContent(sel, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "letter") { l ->
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF5C9DFF).copy(alpha = 0.18f)).padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("${l.ch}${l.ch.lowercase()}", fontSize = 56.sp, fontWeight = FontWeight.Bold)
                    Text("يُنطق: ${l.say}", style = Ltr.copy(color = Color.LightGray))
                    Text("${l.ex} = ${l.exAr}", style = Ltr.copy(fontSize = 18.sp))
                    if (l.tip.isNotBlank()) Text(l.tip, color = Color(0xFFFFCA28), fontSize = 13.sp, textAlign = TextAlign.Center)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = { speaker.speak(l.say, speed) }) { Text("🔊 الحرف") }
                        Button(onClick = { speaker.speak(l.ex, speed) }) { Text("🔊 الكلمة") }
                    }
                }
            }
        }
        items(LETTERS) { l ->
            Box(
                Modifier.aspectRatio(1f).clip(RoundedCornerShape(16.dp))
                    .background(if (l == sel) Color(0xFF5C9DFF) else MaterialTheme.colorScheme.surface)
                    .clickable { sel = l; speaker.speak(l.say, speed) },
                contentAlignment = Alignment.Center
            ) { Text(l.ch, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text("أصوات مهمة", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleMedium)
        }
        items(COMBOS, span = { GridItemSpan(maxLineSpan) }) { c ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
                    .clickable { speaker.speak(c.ex.substringBefore(" /").substringBefore(","), speed) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(c.combo, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF5C9DFF), modifier = Modifier.width(72.dp))
                Column {
                    Text(c.ex, style = Ltr.copy(fontSize = 16.sp))
                    Text(c.tip, color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.height(24.dp)) }
    }
}

// ---------------------------------------------------------------- Sentence checker (LanguageTool)

data class Issue(val offset: Int, val length: Int, val message: String, val fix: String?, val soft: Boolean = false)

fun applyFixes(text: String, issues: List<Issue>): String {
    val sb = StringBuilder(text)
    var limit = Int.MAX_VALUE
    issues.filter { it.fix != null && !it.soft && it.offset + it.length <= text.length }
        .sortedByDescending { it.offset }
        .forEach {
            if (it.offset + it.length <= limit) {
                sb.replace(it.offset, it.offset + it.length, it.fix!!)
                limit = it.offset
            }
        }
    return sb.toString()
}

@Composable
fun CheckerScreen(speaker: Speaker, speed: Float, onBack: () -> Unit) {
    val ctxForLexicon = LocalContext.current
    var text by remember { mutableStateOf("") }
    var checked by remember { mutableStateOf("") }
    var issues by remember { mutableStateOf<List<Issue>?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val lexicon = remember { Lexicon(ctxForLexicon) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("مصحح الجمل", onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                textStyle = Ltr.copy(fontSize = 18.sp), label = { Text("اكتب جملتك بالألمانية") }
            )
            Button(enabled = text.isNotBlank() && !loading, onClick = {
                loading = true; error = null
                scope.launch {
                    try { val t = text; issues = OfflineChecker.check(t, lexicon); checked = t }
                    catch (e: Exception) { error = "حدث خطأ أثناء الفحص" }
                    loading = false
                }
            }) { Text(if (loading) "جارٍ الفحص..." else "راجع جملتي") }
            error?.let { Text(it, color = Red) }
            Text("يعمل المدقق دون إنترنت ويفحص القواعد الأساسية (الأدوات، تصريف sein/haben، الأحرف الكبيرة، الإملاء الشائع). ليس بديلاً عن معلّم.", color = Color.Gray, fontSize = 12.sp)

            val list = issues
            AnimatedVisibility(list != null, enter = fadeIn() + expandVertically()) {
                val l = list.orEmpty()
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (l.isEmpty()) {
                        Text("✅ لا توجد أخطاء! Sehr gut!", color = Green, fontSize = 20.sp)
                    } else {
                        val marked = buildAnnotatedString {
                            var last = 0
                            l.sortedBy { it.offset }.forEach {
                                if (it.offset >= last && it.offset + it.length <= checked.length) {
                                    append(checked.substring(last, it.offset))
                                    withStyle(SpanStyle(background = (if (it.soft) Color(0xFFFFB300) else Red).copy(alpha = 0.4f))) {
                                        append(checked.substring(it.offset, it.offset + it.length))
                                    }
                                    last = it.offset + it.length
                                }
                            }
                            append(checked.substring(last))
                        }
                        Text("جملتك (الأخطاء مظلّلة):", color = Color.Gray)
                        Text(marked, style = Ltr.copy(fontSize = 18.sp))
                        val fixed = applyFixes(checked, l)
                        Text("الصيغة المصحّحة:", color = Color.Gray)
                        Text(fixed, style = Ltr.copy(fontSize = 18.sp, color = Green, fontWeight = FontWeight.Bold))
                        SpeakButton(fixed, speaker, speed)
                        Text("تفاصيل الأخطاء:", color = Color.Gray)
                        l.forEach {
                            Column(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                    .background(MaterialTheme.colorScheme.surface).padding(12.dp)
                            ) {
                                Text("«${checked.substring(it.offset, minOf(checked.length, it.offset + it.length)).ifEmpty { "…" }}»" +
                                    (it.fix?.let { f -> "  →  $f" } ?: ""), style = Ltr.copy(fontWeight = FontWeight.Bold))
                                Text((if (it.soft) "💡 تلميح: " else "") + it.message, color = Color.LightGray, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
