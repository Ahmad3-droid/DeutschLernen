package com.deutschlernen

import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.compose.ui.graphics.Color
import java.util.Locale

data class Word(val de: String, val ar: String, val ex: String)
data class Level(val code: String, val title: String, val color: Color, val subs: List<String>)
data class Letter(val ch: String, val say: String, val ex: String, val exAr: String, val tip: String = "")
data class Combo(val combo: String, val ex: String, val tip: String)

sealed class Screen {
    data object Home : Screen()
    data class Sub(val level: Level, val code: String) : Screen()
    data object Alphabet : Screen()
    data object Checker : Screen()
    data object Sounds : Screen()
    data object Sentences : Screen()
    data object Quiz : Screen()
    data object Translate : Screen()
    data object Saved : Screen()
}

val LEVELS = listOf(
    Level("A1", "مبتدئ", Color(0xFF4CAF50), listOf("A1.1", "A1.2")),
    Level("A2", "أساسي", Color(0xFF42A5F5), listOf("A2.1", "A2.2")),
    Level("B1", "متوسط", Color(0xFFFFA726), listOf("B1.1", "B1.2")),
    Level("B2", "فوق المتوسط", Color(0xFFAB47BC), listOf("B2.1", "B2.2")),
)

fun loadWords(ctx: Context, code: String): List<Word> = try {
    ctx.assets.open("words_${code.replace('.', '_')}.txt").bufferedReader().readLines()
        .filter { it.isNotBlank() }
        .map { l -> val p = l.split(";"); Word(p[0].trim(), p.getOrElse(1) { "" }.trim(), p.getOrElse(2) { "" }.trim()) }
} catch (e: Exception) { emptyList() }

val LETTERS = listOf(
    Letter("A", "Ah", "Apfel", "تفاحة"), Letter("B", "Beh", "Buch", "كتاب"),
    Letter("C", "Tseh", "Computer", "حاسوب", "نادراً وحده؛ يُنطق k أو ts حسب الكلمة"),
    Letter("D", "Deh", "Danke", "شكراً"), Letter("E", "Eh", "Essen", "طعام"),
    Letter("F", "Eff", "Familie", "عائلة"),
    Letter("G", "Geh", "Gut", "جيد", "جيم قاسية (g) مثل gut"),
    Letter("H", "Hah", "Haus", "بيت", "هاء خفيفة أول الكلمة، وتصمت بعد حرف العلة مثل sehen"),
    Letter("I", "Ih", "Idee", "فكرة"),
    Letter("J", "Jott", "Ja", "نعم", "تُنطق مثل y في yes"),
    Letter("K", "Kah", "Kind", "طفل"), Letter("L", "Ell", "Lernen", "يتعلّم"),
    Letter("M", "Emm", "Mutter", "أم"), Letter("N", "Enn", "Name", "اسم"),
    Letter("O", "Oh", "Ofen", "فرن"), Letter("P", "Peh", "Papier", "ورق"),
    Letter("Q", "Kuh", "Quelle", "مصدر", "qu تُنطق kv"),
    Letter("R", "Err", "Rot", "أحمر", "راء حلقية خفيفة من الحلق"),
    Letter("S", "Ess", "Sonne", "شمس", "قبل حرف العلة تُنطق z مجهورة"),
    Letter("T", "Teh", "Tisch", "طاولة"), Letter("U", "Uh", "Uhr", "ساعة"),
    Letter("V", "Fau", "Vater", "أب", "غالباً تُنطق f"),
    Letter("W", "Weh", "Wasser", "ماء", "تُنطق v"),
    Letter("X", "Iks", "Taxi", "تاكسي"), Letter("Y", "Ypsilon", "Yoga", "يوغا"),
    Letter("Z", "Tsett", "Zeit", "وقت", "تُنطق ts"),
    Letter("Ä", "Äh", "Äpfel", "تفاحات", "بين a و e"),
    Letter("Ö", "Öh", "Öl", "زيت", "دوّر الشفتين وانطق e"),
    Letter("Ü", "Üh", "Über", "فوق", "دوّر الشفتين وانطق i"),
    Letter("ß", "Eszett", "Straße", "شارع", "تُنطق ss"),
)

val COMBOS = listOf(
    Combo("ch", "ich / Buch", "بعد i و e خفيفة (ich)، وبعد a o u خشنة من الحلق (Buch)"),
    Combo("sch", "Schule", "تُنطق ش"),
    Combo("ei", "nein", "تُنطق آي"),
    Combo("ie", "Liebe", "ياء طويلة"),
    Combo("eu / äu", "neu", "تُنطق oy"),
    Combo("sp / st", "Sprache, Stein", "أول الكلمة: شب / شت"),
    Combo("pf", "Pferd", "p و f معاً بسرعة"),
)
