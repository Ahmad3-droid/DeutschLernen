package com.deutschlernen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { App() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF5C9DFF),
            background = Color(0xFF0E1420),
            surface = Color(0xFF151D2E),
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { content() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val speaker = remember { Speaker(ctx) }
    val store = remember { SavedStore(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var speed by remember { mutableFloatStateOf(1f) }
    BackHandler(screen != Screen.Home) { screen = Screen.Home }
    val back = { screen = Screen.Home }

    CompositionLocalProvider(LocalStore provides store) {
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                (fadeIn(tween(300)) + slideInHorizontally(tween(300)) { it / 4 }) togetherWith fadeOut(tween(200))
            },
            label = "nav"
        ) { s ->
            when (s) {
                Screen.Home -> Home { screen = it }
                is Screen.Sub -> SubScreen(s.code, s.level.color, speaker, speed, { speed = it }, back)
                Screen.Alphabet -> AlphabetScreen(speaker, speed, { speed = it }, back)
                Screen.Checker -> CheckerScreen(speaker, speed, back)
                Screen.Sounds -> SoundsScreen(speaker, speed, { speed = it }, back)
                Screen.Sentences -> SentencesScreen(speaker, speed, { speed = it }, back)
                Screen.Quiz -> QuizScreen(speaker, speed, { speed = it }, back)
                Screen.Translate -> TranslateScreen(speaker, speed, back)
                Screen.Saved -> SavedScreen(speaker, speed, { speed = it }, back)
            }
        }
    }
}

@Composable
fun Home(onNav: (Screen) -> Unit) {
    var open by remember { mutableStateOf<String?>(null) }
    val features = listOf(
        "🔤 الأبجدية" to Screen.Alphabet,
        "🔊 الأصوات" to Screen.Sounds,
        "💬 الجمل" to Screen.Sentences,
        "🧠 اختبار عشوائي" to Screen.Quiz,
        "🌐 مترجم" to Screen.Translate,
        "💾 محفوظاتي" to Screen.Saved,
        "✍️ مصحح الجمل" to Screen.Checker,
    )
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(Modifier.padding(top = 24.dp, bottom = 8.dp)) {
                Text("Deutsch Lernen 🇩🇪", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("تعلّم الألمانية من الصفر حتى B2", color = Color.Gray)
            }
        }
        itemsIndexed(LEVELS) { i, lv ->
            var visible by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { delay(i * 130L); visible = true }
            AnimatedVisibility(visible, enter = fadeIn(tween(400)) + slideInVertically(tween(400)) { it / 2 }) {
                Column(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(lv.color.copy(alpha = 0.18f))
                        .clickable { open = if (open == lv.code) null else lv.code }
                        .animateContentSize()
                        .padding(20.dp)
                ) {
                    Text(lv.code, fontSize = 40.sp, fontWeight = FontWeight.Bold, color = lv.color)
                    Text(lv.title, color = Color.LightGray)
                    AnimatedVisibility(open == lv.code) {
                        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            lv.subs.forEach { sub ->
                                Button(
                                    onClick = { onNav(Screen.Sub(lv, sub)) },
                                    colors = ButtonDefaults.buttonColors(containerColor = lv.color),
                                    modifier = Modifier.weight(1f)
                                ) { Text(sub, fontSize = 18.sp) }
                            }
                        }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                features.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (title, target) ->
                            FilledTonalButton(onClick = { onNav(target) }, Modifier.weight(1f)) { Text(title) }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
