package com.deutschlernen

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.TweenSpec
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.TextUnit
import kotlin.math.abs

enum class Tier(val label: String, val device: String) {
    LOW("موفّر", "ضعيف"),
    MID("متوازن", "متوسط"),
    HIGH("عالٍ", "قوي")
}

/** إعدادات الأداء: تلقائي حسب قوة الجهاز أو يدوي. */
object Perf {
    var mode by mutableStateOf("auto")          // auto | low | high
    var detected by mutableStateOf(Tier.MID)

    val tier: Tier
        get() = when (mode) {
            "low" -> Tier.LOW
            "high" -> Tier.HIGH
            else -> detected
        }
    val scale: Float
        get() = when (tier) {
            Tier.LOW -> 0.6f
            Tier.MID -> 0.85f
            Tier.HIGH -> 1f
        }
    val fancy: Boolean get() = tier != Tier.LOW
}

fun <T> fxTween(ms: Int): TweenSpec<T> = tween((ms * Perf.scale).toInt().coerceAtLeast(1))

fun detectTier(ctx: Context): Tier = try {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val ramGb = info.totalMem / (1024.0 * 1024.0 * 1024.0)
    val cores = Runtime.getRuntime().availableProcessors()
    when {
        am.isLowRamDevice || ramGb < 2.5 || Build.VERSION.SDK_INT < 26 -> Tier.LOW
        ramGb >= 5.0 && cores >= 8 && Build.VERSION.SDK_INT >= 29 -> Tier.HIGH
        else -> Tier.MID
    }
} catch (e: Exception) {
    Tier.MID
}

/** يطلب من النظام معدل تحديث مناسب: الأعلى للأجهزة القوية و60Hz للضعيفة. */
@Suppress("DEPRECATION")
fun applyRefreshRate(activity: Activity, tier: Tier) {
    try {
        val display = (if (Build.VERSION.SDK_INT >= 30) activity.display else activity.windowManager.defaultDisplay)
            ?: return
        val cur = display.mode
        val same = display.supportedModes.filter {
            it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight
        }
        val target = when (tier) {
            Tier.HIGH -> same.maxByOrNull { it.refreshRate }
            Tier.MID -> same.filter { it.refreshRate <= 90.5f }.maxByOrNull { it.refreshRate }
            Tier.LOW -> same.minByOrNull { abs(it.refreshRate - 60f) }
        } ?: return
        val lp = activity.window.attributes
        lp.preferredDisplayModeId = target.modeId
        activity.window.attributes = lp
    } catch (e: Exception) {
    }
}

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** نقر مع تأثير انضغاط ناعم (يُرسم دون إعادة تركيب). */
fun Modifier.bounceClick(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.95f else 1f, fxTween(120), label = "bounce")
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** إيموجي بحركة مختلفة حسب النوع، ثابت على الأجهزة الضعيفة. */
@androidx.compose.runtime.Composable
fun AnimatedEmoji(emoji: String, kind: Int, size: TextUnit) {
    if (!Perf.fancy) {
        Text(emoji, fontSize = size)
        return
    }
    val inf = rememberInfiniteTransition(label = "emo")
    val v by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1100 + (kind % 4) * 180, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "v"
    )
    Text(emoji, fontSize = size, modifier = Modifier.graphicsLayer {
        when (kind % 4) {
            0 -> { translationY = -10f * v }
            1 -> { scaleX = 1f + 0.18f * v; scaleY = 1f + 0.18f * v }
            2 -> { rotationZ = -12f + 24f * v }
            else -> { alpha = 0.65f + 0.35f * v; translationY = 4f * v }
        }
    })
}
