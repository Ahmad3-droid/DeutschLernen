@file:OptIn(ExperimentalMaterial3Api::class)

package com.deutschlernen

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

private val QGreen = Color(0xFF4CAF50)
private val QRed = Color(0xFFEF5350)
private val Accent = Color(0xFF5C9DFF)

@Composable
fun MiniSpeak(text: String, speaker: Speaker, speed: Float) {
    val ctx = LocalContext.current
    FilledTonalButton(
        onClick = {
            if (!speaker.speak(text, speed))
                Toast.makeText(ctx, "ثبّت صوت اللغة الألمانية من إعدادات تحويل النص إلى كلام", Toast.LENGTH_LONG).show()
        },
        contentPadding = PaddingValues(horizontal = 14.dp)
    ) { Text("🔊") }
}

@Composable
fun SaveButton(w: Word) {
    val store = LocalStore.current
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { open = true }) { Text("💾 حفظ") }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text("احفظ في أي خانة؟") },
            text = {
                Column {
                    CATS.forEach { c ->
                        TextButton(onClick = {
                            val ok = store.add(c.key, w.de, w.ar)
                            Toast.makeText(ctx, if (ok) "تم الحفظ في ${c.title}" else "موجودة مسبقاً", Toast.LENGTH_SHORT).show()
                            open = false
                        }) { Text("${c.icon}  ${c.title}", fontSize = 18.sp) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { open = false }) { Text("إلغاء") } }
        )
    }
}

// ============================================================ الأصوات

data class SoundItem(val group: String, val sym: String, val tip: String, val words: List<Pair<String, String>>)

val SOUNDS = listOf(
    SoundItem("حروف العلة", "a", "طويلة في Bahn وقصيرة في Mann", listOf("Bahn" to "قطار", "Mann" to "رجل")),
    SoundItem("حروف العلة", "e", "طويلة (ي مفتوحة) أو قصيرة، وفي آخر الكلمة تُنطق خفيفة", listOf("Lehrer" to "معلم", "Bett" to "سرير", "Name" to "اسم")),
    SoundItem("حروف العلة", "i", "قصيرة في Kind وطويلة في Ziel", listOf("Kind" to "طفل", "Ziel" to "هدف")),
    SoundItem("حروف العلة", "o", "ضمّة مفتوحة: طويلة في Boot وقصيرة في Sonne", listOf("Boot" to "قارب", "Sonne" to "شمس")),
    SoundItem("حروف العلة", "u", "ضمّة: طويلة في gut وقصيرة في Mund", listOf("gut" to "جيد", "Mund" to "فم")),
    SoundItem("الحروف المعدّلة", "ä", "بين a و e (مثل «أيْ» مفتوحة)", listOf("Käse" to "جبن", "Äpfel" to "تفاحات")),
    SoundItem("الحروف المعدّلة", "ö", "دوّر الشفتين وانطق e", listOf("schön" to "جميل", "können" to "يستطيع")),
    SoundItem("الحروف المعدّلة", "ü", "دوّر الشفتين وانطق i", listOf("Tür" to "باب", "müssen" to "يجب")),
    SoundItem("الثنائيات", "ei", "تُنطق «آي»", listOf("Eis" to "ثلج / مثلجات", "mein" to "ملكي")),
    SoundItem("الثنائيات", "ie", "ياء طويلة", listOf("Liebe" to "حب", "Tier" to "حيوان")),
    SoundItem("الثنائيات", "eu / äu", "تُنطق «أوي»", listOf("heute" to "اليوم", "Häuser" to "بيوت")),
    SoundItem("الثنائيات", "au", "تُنطق «آو»", listOf("Haus" to "بيت", "Auto" to "سيارة")),
    SoundItem("السواكن", "ch (بعد i, e, ä, ö, ü)", "صوت خفيف من وسط اللسان قرب الحنك", listOf("ich" to "أنا", "Milch" to "حليب", "wichtig" to "مهم")),
    SoundItem("السواكن", "ch (بعد a, o, u)", "صوت خشن من الحلق مثل خ", listOf("Buch" to "كتاب", "acht" to "ثمانية")),
    SoundItem("السواكن", "sch", "تُنطق ش", listOf("Schule" to "مدرسة", "Tisch" to "طاولة")),
    SoundItem("السواكن", "sp / st (أول الكلمة)", "تُنطق شب / شت", listOf("Sport" to "رياضة", "Stein" to "حجر")),
    SoundItem("السواكن", "s", "قبل حرف علة تُنطق z مجهورة", listOf("Sonne" to "شمس", "Rose" to "وردة")),
    SoundItem("السواكن", "ß / ss", "تُنطق سين مشددة", listOf("Straße" to "شارع", "Wasser" to "ماء")),
    SoundItem("السواكن", "z / tz", "تُنطق ts", listOf("Zeit" to "وقت", "Katze" to "قطة")),
    SoundItem("السواكن", "v", "غالباً تُنطق f", listOf("Vater" to "أب", "Vogel" to "طائر")),
    SoundItem("السواكن", "w", "تُنطق v", listOf("Wasser" to "ماء", "Wein" to "نبيذ")),
    SoundItem("السواكن", "j", "تُنطق y", listOf("Jahr" to "سنة", "ja" to "نعم")),
    SoundItem("السواكن", "r", "راء حلقية خفيفة، وفي آخر الكلمة تقترب من a", listOf("rot" to "أحمر", "Bruder" to "أخ")),
    SoundItem("السواكن", "ng", "صوت أنفي واحد دون g مستقلة", listOf("Ding" to "شيء", "lang" to "طويل")),
    SoundItem("السواكن", "pf", "p و f معاً بسرعة", listOf("Pferd" to "حصان", "Apfel" to "تفاحة")),
    SoundItem("السواكن", "qu", "تُنطق kv", listOf("Quelle" to "مصدر", "Qualität" to "جودة")),
    SoundItem("السواكن", "h", "هاء خفيفة أول المقطع وتصمت بعد حرف العلة", listOf("Haus" to "بيت", "sehen" to "يرى")),
)

@Composable
fun SoundsScreen(speaker: Speaker, speed: Float, onSpeed: (Float) -> Unit, onBack: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { TopBar("الأصوات الألمانية", onBack) }
        item { SpeedBar(speed, onSpeed) }
        SOUNDS.forEachIndexed { i, s ->
            if (i == 0 || SOUNDS[i - 1].group != s.group) {
                item { Text(s.group, style = MaterialTheme.typography.titleMedium, color = Accent, modifier = Modifier.padding(top = 12.dp)) }
            }
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surface).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(s.sym, style = Ltr.copy(fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent))
                        Text(s.tip, color = Color.LightGray, fontSize = 13.sp)
                    }
                    s.words.forEach { (de, ar) ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .clickable { speaker.speak(de, speed) }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("🔊")
                            Text(de, style = Ltr.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold), modifier = Modifier.weight(1f))
                            Text(ar, color = Color.Gray)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

// ============================================================ الجمل

data class Sentence(val cat: String, val de: String, val ar: String)

fun loadSentences(ctx: android.content.Context): List<Sentence> = try {
    ctx.assets.open("sentences.txt").bufferedReader().readLines().filter { it.isNotBlank() }.map {
        val p = it.split(";")
        Sentence(p[0].trim(), p.getOrElse(1) { "" }.trim(), p.getOrElse(2) { "" }.trim())
    }
} catch (e: Exception) { emptyList() }

@Composable
fun SentencesScreen(speaker: Speaker, speed: Float, onSpeed: (Float) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val all = remember { loadSentences(ctx) }
    val cats = remember { listOf("الكل") + all.map { it.cat }.distinct() }
    var sel by remember { mutableStateOf("الكل") }
    val list = if (sel == "الكل") all else all.filter { it.cat == sel }
    Column(Modifier.fillMaxSize()) {
        TopBar("قائمة الجمل", onBack)
        SpeedBar(speed, onSpeed)
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cats) { c -> FilterChip(selected = sel == c, onClick = { sel = c }, label = { Text(c) }) }
        }
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list) { s ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surface).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(s.de, style = Ltr.copy(fontSize = 17.sp, fontWeight = FontWeight.SemiBold))
                        Text(s.ar, color = Color.Gray, fontSize = 14.sp)
                    }
                    MiniSpeak(s.de, speaker, speed)
                }
            }
        }
    }
}

// ============================================================ الاختبارات

data class Q(
    val prompt: String, val speak: String?, val options: List<String>, val answer: String,
    val arOptions: Boolean, val de: String, val ar: String
)

fun poolFor(ctx: android.content.Context, level: String): List<Word> =
    LEVELS.filter { level == "الكل" || it.code == level }.flatMap { it.subs }.flatMap { loadWords(ctx, it) }

fun makeQuiz(pool: List<Word>, n: Int = 10): List<Q> =
    pool.shuffled().take(n).mapIndexed { i, w ->
        val others = pool.filter { it.ar != w.ar && it.de != w.de }.shuffled().take(3)
        when (i % 3) {
            1 -> Q(w.ar, null, (others.map { it.de } + w.de).distinct().shuffled(), w.de, false, w.de, w.ar)
            2 -> Q("🔊", w.de, (others.map { it.ar } + w.ar).distinct().shuffled(), w.ar, true, w.de, w.ar)
            else -> Q(w.de, null, (others.map { it.ar } + w.ar).distinct().shuffled(), w.ar, true, w.de, w.ar)
        }
    }

@Composable
fun OptionButton(text: String, state: Int, ltr: Boolean, onClick: () -> Unit) {
    val target = when (state) {
        1 -> QGreen.copy(alpha = 0.45f)
        2 -> QRed.copy(alpha = 0.45f)
        else -> MaterialTheme.colorScheme.surface
    }
    val bg by animateColorAsState(target, fxTween(300), label = "opt")
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = bg, contentColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
    ) {
        Text(text, style = if (ltr) Ltr.copy(fontSize = 18.sp) else Ltr.copy(fontSize = 18.sp, textDirection = androidx.compose.ui.text.style.TextDirection.Content))
    }
}

@Composable
fun QuizScreen(speaker: Speaker, speed: Float, onSpeed: (Float) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var level by remember { mutableStateOf("الكل") }
    var quiz by remember { mutableStateOf<List<Q>?>(null) }
    var idx by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<String?>(null) }
    val wrong = remember { mutableStateListOf<Q>() }
    val q = quiz

    Column(Modifier.fillMaxSize()) {
        TopBar("اختبار عشوائي", onBack)
        if (q == null) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("اختر مستوى الاختبار (10 أسئلة عشوائية):", color = Color.Gray)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("الكل", "A1", "A2", "B1", "B2")) { l ->
                        FilterChip(selected = level == l, onClick = { level = l }, label = { Text(l) })
                    }
                }
                SpeedBar(speed, onSpeed)
                Text("أنواع الأسئلة: معنى الكلمة، الكلمة الألمانية، والاستماع.", color = Color.Gray, fontSize = 13.sp)
                Button(onClick = {
                    val pool = poolFor(ctx, level)
                    if (pool.size < 4) Toast.makeText(ctx, "لا توجد كلمات كافية", Toast.LENGTH_SHORT).show()
                    else { quiz = makeQuiz(pool); idx = 0; score = 0; picked = null; wrong.clear() }
                }, Modifier.fillMaxWidth()) { Text("ابدأ الاختبار 🚀") }
            }
        } else if (idx >= q.size) {
            var show by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { show = true }
            val sc by animateFloatAsState(if (show) 1f else 0f, spring(dampingRatio = 0.4f), label = "res")
            val ratio = score.toFloat() / q.size
            Column(
                Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(if (ratio >= 0.8f) "🏆" else if (ratio >= 0.5f) "👍" else "💪", fontSize = 64.sp, modifier = Modifier.scale(sc))
                Text("$score / ${q.size}", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Accent, modifier = Modifier.scale(sc))
                Text(if (ratio >= 0.8f) "ممتاز! Sehr gut!" else if (ratio >= 0.5f) "جيد، استمر!" else "لا بأس، كرّر المحاولة", fontSize = 18.sp)
                if (wrong.isNotEmpty()) {
                    Text("كلمات أخطأت فيها:", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
                    wrong.forEach { w ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surface).padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(w.de, style = Ltr.copy(fontWeight = FontWeight.Bold, fontSize = 17.sp))
                                Text(w.ar, color = Color.Gray)
                            }
                            MiniSpeak(w.de, speaker, speed)
                        }
                    }
                }
                Button(onClick = { quiz = null }, Modifier.fillMaxWidth()) { Text("اختبار جديد 🔄") }
            }
        } else {
            val cur = q[idx]
            LaunchedEffect(idx) { cur.speak?.let { speaker.speak(it, speed) } }
            Column(
                Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                LinearProgressIndicator(progress = { idx / q.size.toFloat() }, Modifier.fillMaxWidth())
                Text("السؤال ${idx + 1} / ${q.size}      ✅ $score", color = Color.Gray)
                Text(
                    if (cur.speak != null) "ماذا تعني الكلمة التي سمعتها؟"
                    else if (cur.arOptions) "ما معنى هذه الكلمة؟" else "ما الكلمة الألمانية المناسبة؟"
                )
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                        .background(Accent.copy(alpha = 0.18f)).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (cur.speak != null) SpeakButton(cur.speak, speaker, speed)
                    else Text(cur.prompt, style = Ltr.copy(fontSize = 30.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center))
                }
                cur.options.forEach { opt ->
                    val state = if (picked == null) 0 else if (opt == cur.answer) 1 else if (opt == picked) 2 else 0
                    OptionButton(opt, state, !cur.arOptions) {
                        if (picked == null) {
                            picked = opt
                            if (opt == cur.answer) score++ else wrong.add(cur)
                        }
                    }
                }
                AnimatedVisibility(picked != null) {
                    Button(onClick = { idx++; picked = null }, Modifier.fillMaxWidth()) {
                        Text(if (idx == q.size - 1) "عرض النتيجة" else "التالي")
                    }
                }
            }
        }
    }
}

// ============================================================ المترجم

fun translateText(text: String, fromDe: Boolean, onDone: (String) -> Unit, onError: (String) -> Unit) {
    val opts = TranslatorOptions.Builder()
        .setSourceLanguage(if (fromDe) TranslateLanguage.GERMAN else TranslateLanguage.ARABIC)
        .setTargetLanguage(if (fromDe) TranslateLanguage.ARABIC else TranslateLanguage.GERMAN)
        .build()
    val tr = Translation.getClient(opts)
    tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
        .addOnSuccessListener {
            tr.translate(text)
                .addOnSuccessListener { onDone(it); tr.close() }
                .addOnFailureListener { onError("فشلت الترجمة، حاول مجدداً"); tr.close() }
        }
        .addOnFailureListener {
            onError("تحتاج إلى الإنترنت مرة واحدة لتحميل نموذج الترجمة، وبعدها يعمل بدونه")
            tr.close()
        }
}

@Composable
fun CheckSummary(text: String, issues: List<Issue>) {
    if (issues.isEmpty()) {
        Text("✅ لا أخطاء قواعدية ظاهرة", color = QGreen)
        return
    }
    val marked = buildAnnotatedString {
        var last = 0
        issues.sortedBy { it.offset }.forEach {
            if (it.offset >= last && it.offset + it.length <= text.length) {
                append(text.substring(last, it.offset))
                withStyle(SpanStyle(background = (if (it.soft) Color(0xFFFFB300) else QRed).copy(alpha = 0.4f))) {
                    append(text.substring(it.offset, it.offset + it.length))
                }
                last = it.offset + it.length
            }
        }
        append(text.substring(last))
    }
    Text("النص الأصلي (الأخطاء مظلّلة):", color = Color.Gray)
    Text(marked, style = Ltr.copy(fontSize = 17.sp))
    Text("بعد التصحيح:", color = Color.Gray)
    Text(applyFixes(text, issues), style = Ltr.copy(fontSize = 17.sp, color = QGreen, fontWeight = FontWeight.Bold))
    issues.forEach {
        Text("• " + (if (it.soft) "💡 " else "") + it.message, color = Color.LightGray, fontSize = 13.sp)
    }
}

@Composable
fun TranslateScreen(speaker: Speaker, speed: Float, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val lexicon = remember { Lexicons.get(ctx) }
    var deToAr by remember { mutableStateOf(true) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var checked by remember { mutableStateOf("") }
    var issues by remember { mutableStateOf<List<Issue>>(emptyList()) }
    var output by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("مترجم مع تصحيح", onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = deToAr, onClick = { deToAr = true; done = false }, label = { Text("ألماني ← عربي") })
                FilterChip(selected = !deToAr, onClick = { deToAr = false; done = false }, label = { Text("عربي ← ألماني") })
            }
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                textStyle = if (deToAr) Ltr.copy(fontSize = 18.sp) else Ltr.copy(fontSize = 18.sp, textDirection = androidx.compose.ui.text.style.TextDirection.Content),
                label = { Text(if (deToAr) "اكتب النص بالألمانية" else "اكتب النص بالعربية") }
            )
            Button(enabled = input.isNotBlank() && !busy, onClick = {
                busy = true; status = null; done = false
                if (deToAr) {
                    val iss = runCatching { OfflineChecker.check(input, lexicon) }.getOrDefault(emptyList())
                    issues = iss; checked = input
                    translateText(applyFixes(input, iss), true,
                        { output = it; busy = false; done = true },
                        { status = it; busy = false })
                } else {
                    translateText(input, false,
                        { out ->
                            output = out; checked = out
                            issues = runCatching { OfflineChecker.check(out, lexicon) }.getOrDefault(emptyList())
                            busy = false; done = true
                        },
                        { status = it; busy = false })
                }
            }) { Text(if (busy) "جارٍ الترجمة..." else "ترجم وصحّح") }
            status?.let { Text(it, color = QRed) }
            Text(
                "أول استخدام يحتاج إنترنت لتحميل نموذج الترجمة (نحو 30MB لكل لغة)، وبعدها تعمل الترجمة دون إنترنت.",
                color = Color.Gray, fontSize = 12.sp
            )
            AnimatedVisibility(done, enter = fadeIn() + expandVertically()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (deToAr) {
                        CheckSummary(checked, issues)
                        Text("الترجمة (للنص بعد التصحيح):", color = Color.Gray)
                        Text(output, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        MiniSpeak(applyFixes(checked, issues), speaker, speed)
                    } else {
                        Text("الترجمة الألمانية:", color = Color.Gray)
                        Text(output, style = Ltr.copy(fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Accent))
                        SpeakButton(output, speaker, speed)
                        if (issues.isNotEmpty()) CheckSummary(output, issues)
                    }
                }
            }
        }
    }
}

// ============================================================ المحفوظات

@Composable
fun SavedScreen(speaker: Speaker, speed: Float, onSpeed: (Float) -> Unit, onBack: () -> Unit) {
    val store = LocalStore.current
    val ctx = LocalContext.current
    var sel by remember { mutableStateOf(CATS[0]) }
    var adding by remember { mutableStateOf(false) }
    var de by remember { mutableStateOf("") }
    var ar by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        TopBar("محفوظاتي", onBack)
        SpeedBar(speed, onSpeed)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CATS.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { c ->
                        val count = store.items.count { it.cat == c.key }
                        val bg by animateColorAsState(
                            if (c == sel) Accent.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface, label = "cat"
                        )
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(bg)
                                .clickable { sel = c }.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(c.icon, fontSize = 26.sp)
                            Text(c.title, fontWeight = FontWeight.Bold)
                            Text("$count", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        val list = store.items.filter { it.cat == sel.key }
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (list.isEmpty()) item { Text("الخانة فارغة، أضف كلماتك بالزر أدناه.", color = Color.Gray) }
            items(list) { item ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(item.de, style = Ltr.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold))
                        Text(item.ar, color = Color.Gray)
                    }
                    MiniSpeak(item.de, speaker, speed)
                    TextButton(onClick = { store.remove(item) }) { Text("🗑") }
                }
            }
        }
        Button(onClick = { adding = true }, Modifier.fillMaxWidth().padding(16.dp)) {
            Text("➕ إضافة إلى ${sel.title}")
        }
    }

    if (adding) {
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("إضافة إلى ${sel.title}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(de, { de = it }, label = { Text("بالألمانية") }, singleLine = true, textStyle = Ltr)
                    OutlinedTextField(ar, { ar = it }, label = { Text("المعنى بالعربية") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (store.add(sel.key, de, ar)) { adding = false; de = ""; ar = "" }
                    else Toast.makeText(ctx, "الكلمة فارغة أو موجودة مسبقاً", Toast.LENGTH_SHORT).show()
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("إلغاء") } }
        )
    }
}
