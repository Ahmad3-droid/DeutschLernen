package com.deutschlernen

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class Speaker(ctx: Context) {
    var ready = false
        private set
    private lateinit var tts: TextToSpeech
    private var created = false

    init {
        try {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                try {
                    if (status == TextToSpeech.SUCCESS) {
                        val r = tts.setLanguage(Locale.GERMANY)
                        ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    }
                } catch (e: Exception) {
                    ready = false
                }
            }
            created = true
        } catch (e: Exception) {
            created = false
        }
    }

    fun speak(text: String, rate: Float): Boolean {
        if (!ready || !created) return false
        return try {
            tts.setSpeechRate(rate)
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "de")
            true
        } catch (e: Exception) {
            false
        }
    }

    fun shutdown() {
        try {
            if (created) {
                tts.stop()
                tts.shutdown()
            }
        } catch (e: Exception) {
        }
    }
}
