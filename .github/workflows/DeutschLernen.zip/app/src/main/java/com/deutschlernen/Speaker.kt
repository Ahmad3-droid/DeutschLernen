package com.deutschlernen

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class Speaker(ctx: Context) {
    var ready = false
        private set
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts.setLanguage(Locale.GERMANY)
                ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    fun speak(text: String, rate: Float): Boolean {
        if (!ready) return false
        tts.setSpeechRate(rate)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "de")
        return true
    }

    fun shutdown() { tts.stop(); tts.shutdown() }
}
