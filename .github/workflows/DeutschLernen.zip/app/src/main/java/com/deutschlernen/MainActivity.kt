@file:OptIn(ExperimentalMaterial3Api::class)

package com.deutschlernen

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("perf", Context.MODE_PRIVATE)
        Perf.detected = detectTier(this)
        Perf.mode = prefs.getString("mode", "auto") ?: "auto"
        applyRefreshRate(this, Perf.tier)
        // تحميل القاموس في الخلفية كي لا يتأخر فتح الشاشات
        Thread { try { Lexicons.get(applicationContext) } catch (e: Exception) { } }.start()
        setContent { AppTheme { App() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF5C9DFF),
            background = Color(0xFF0E1420),
            surface = Color(0xFF151D2E),
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { content() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val speaker = remember { Speaker(ctx) }
    val store = remember { SavedStore(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var speed by remember { mutableFloatStateOf(1f) }
    BackHandler(screen != Screen.Home) { screen = Screen.Home }
    val back = { screen = Screen.Home }

    CompositionLocalProvider(LocalStore provides store) {
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                (fadeIn(fxTween(300)) + slideInHorizontally(fxTween(300)) { it / 4 }) togetherWith fadeOut(fxTween(200))
            },
            label = "nav"
        ) { s ->
            when (s) {
                Screen.Home -> Home { screen = it }
                is Screen.Sub -> SubScreen(s.code, s.level.color, speaker, speed, { speed = it }, back)
                Screen.Alphabet -> AlphabetScreen(speaker, speed, { speed = it }, back)
                Screen.Checker -> CheckerScreen(speaker, speed, back)
                Screen.Sounds -> SoundsScreen(speaker, speed, { speed = it }, back)
                Screen.Sentences -> SentencesScreen(speaker, speed, { speed = it }, back)
                Screen.Quiz -> QuizScreen(speaker, speed, { speed = it }, back)
                Screen.Translate -> TranslateScreen(speaker, speed, back)
                Screen.Saved -> SavedScreen(speaker, speed, { speed = it }, back)
            }
        }
    }
}

private val LEVEL_DESC = mapOf(
    "A1" to "مبتدئ: التحيات والأرقام والعائلة",
    "A2" to "أساسي: السفر والتسوق والصحة",
    "B1" to "متوسط: الآراء والمجتمع والبيئة",
    "B2" to "متقدم: النقاش والتعبير الدقيق",
)

@Composable
fun Home(onNav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf<String?>(null) }
    val features = remember {
        listOf(
            Triple("🔤", "الأبجدية", Screen.Alphabet),
            Triple("🔊", "الأصوات", Screen.Sounds),
            Triple("💬", "الجمل", Screen.Sentences),
            Triple("🧠", "اختبار عشوائي", Screen.Quiz),
            Triple("🌐", "مترجم", Screen.Translate),
            Triple("💾", "محفوظاتي", Screen.Saved),
            Triple("✍️", "مصحح الجمل", Screen.Checker),
        )
    }
    val setMode: (String) -> Unit = { m ->
        Perf.mode = m
        ctx.getSharedPreferences("perf", Context.MODE_PRIVATE).edit().putString("mode", m).apply()
        ctx.findActivity()?.let { applyRefreshRate(it, Perf.tier) }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(Modifier.padding(top = 24.dp, bottom = 8.dp)) {
                Text("Deutsch Lernen 🇩🇪", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("تعلّم الألمانية من الصفر حتى B2", color = Color.Gray)
            }
        }
        itemsIndexed(LEVELS) { i, lv ->
            var visible by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { delay((i * 130 * Perf.scale).toLong()); visible = true }
            AnimatedVisibility(visible, enter = fadeIn(fxTween(400)) + slideInVertically(fxTween(400)) { it / 2 }) {
                Column(
                    Modifier.fillMaxWidth()
                        .bounceClick { open = if (open == lv.code) null else lv.code }
                        .clip(RoundedCornerShape(24.dp))
                        .background(Brush.linearGradient(listOf(lv.color.copy(alpha = 0.30f), lv.color.copy(alpha = 0.10f))))
                        .animateContentSize()
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        LevelArt(lv.code, lv.color)
                        Column(Modifier.weight(1f)) {
                            Text(lv.code, fontSize = 36.sp, fontWeight = FontWeight.Bold, color = lv.color)
                            Text(lv.title, color = Color.LightGray)
                            Text(LEVEL_DESC[lv.code] ?: "", color = Color.Gray, fontSize = 12.sp)
                        }
                        Text(if (open == lv.code) "▲" else "▼", color = Color.Gray)
                    }
                    AnimatedVisibility(open == lv.code) {
                        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            lv.subs.forEach { sub ->
                                Button(
                                    onClick = { onNav(Screen.Sub(lv, sub)) },
                                    colors = ButtonDefaults.buttonColors(containerColor = lv.color),
                                    modifier = Modifier.weight(1f)
                                ) { Text(sub, fontSize = 18.sp) }
                            }
                        }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                features.chunked(2).forEachIndexed { r, row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEachIndexed { c, (emoji, title, target) ->
                            Column(
                                Modifier.weight(1f)
                                    .bounceClick { onNav(target) }
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                AnimatedEmoji(emoji, r * 2 + c, 32.sp)
                                Text(title, fontSize = 14.sp)
                            }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.surface).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("⚙️ الأداء والحركة", fontWeight = FontWeight.Bold)
                Text("جهازك: ${Perf.detected.device} · الوضع الحالي: ${Perf.tier.label}", color = Color.Gray, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("auto" to "تلقائي", "low" to "موفّر", "high" to "عالٍ").forEach { (k, l) ->
                        FilterChip(selected = Perf.mode == k, onClick = { setMode(k) }, label = { Text(l) })
                    }
                }
                Text(
                    "الموفّر يقلل الحركة ويثبّت معدل التحديث على 60Hz للأجهزة القديمة، والعالي يستخدم أعلى معدل يدعمه جهازك.",
                    color = Color.Gray, fontSize = 11.sp
                )
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
