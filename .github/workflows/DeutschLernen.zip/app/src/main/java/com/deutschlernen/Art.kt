package com.deutschlernen

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

/** رسوم متحركة مرسومة بالكود لكل مستوى (حادّة وخفيفة، وثابتة على الأجهزة الضعيفة). */
@Composable
fun LevelArt(code: String, color: Color, modifier: Modifier = Modifier) {
    val t: State<Float> = if (Perf.fancy) {
        rememberInfiniteTransition(label = "art").animateFloat(
            0f, 1f,
            infiniteRepeatable(
                tween(if (Perf.tier == Tier.HIGH) 2600 else 3600, easing = LinearEasing),
                RepeatMode.Restart
            ),
            label = "t"
        )
    } else remember { mutableStateOf(0.35f) }

    Canvas(modifier.size(76.dp)) {
        val p = t.value
        val w = size.width
        val h = size.height
        val wave = sin(p * 2f * PI.toFloat())
        val up = (wave + 1f) / 2f
        drawRoundRect(color.copy(alpha = 0.22f), cornerRadius = CornerRadius(w * 0.28f, w * 0.28f))

        when (code) {
            "A1" -> {
                drawCircle(Color(0xFFFFD54F), w * 0.10f * (1f + 0.12f * wave), Offset(w * 0.80f, h * 0.20f))
                drawOval(Color(0xFF6D4C41), Offset(w * 0.18f, h * 0.78f), Size(w * 0.64f, h * 0.16f))
                val grow = 0.75f + 0.25f * up
                val baseY = h * 0.84f
                val topY = baseY - h * 0.40f * grow
                drawLine(Color(0xFF2E7D32), Offset(w * 0.5f, baseY), Offset(w * 0.5f, topY), strokeWidth = w * 0.05f, cap = StrokeCap.Round)
                rotate(-35f, Offset(w * 0.5f, topY + h * 0.10f)) {
                    drawOval(Color(0xFF66BB6A), Offset(w * 0.5f - w * 0.26f * grow, topY + h * 0.04f), Size(w * 0.26f * grow, h * 0.12f * grow))
                }
                rotate(35f, Offset(w * 0.5f, topY + h * 0.10f)) {
                    drawOval(Color(0xFF81C784), Offset(w * 0.5f, topY + h * 0.04f), Size(w * 0.26f * grow, h * 0.12f * grow))
                }
                drawCircle(Color(0xFFA5D6A7), w * 0.06f * grow, Offset(w * 0.5f, topY))
            }
            "A2" -> {
                val bx = w * 0.22f
                val by = h * 0.46f
                val bw = w * 0.56f
                val bh = h * 0.38f
                drawRect(Color(0xFFFFF3E0), Offset(bx, by), Size(bw, bh))
                val roof = Path().apply {
                    moveTo(bx - w * 0.05f, by)
                    lineTo(bx + bw / 2f, h * 0.18f)
                    lineTo(bx + bw + w * 0.05f, by)
                    close()
                }
                drawPath(roof, Color(0xFFE53935))
                drawRect(Color(0xFF6D4C41), Offset(bx + bw * 0.40f, by + bh * 0.45f), Size(bw * 0.2f, bh * 0.55f))
                val glow = 0.55f + 0.45f * up
                drawRect(Color(0xFFFFEB3B).copy(alpha = glow), Offset(bx + bw * 0.10f, by + bh * 0.18f), Size(bw * 0.2f, bh * 0.25f))
                drawRect(Color(0xFFFFEB3B).copy(alpha = glow), Offset(bx + bw * 0.70f, by + bh * 0.18f), Size(bw * 0.2f, bh * 0.25f))
                repeat(3) { i ->
                    val k = (p + i / 3f) % 1f
                    drawCircle(
                        Color.White.copy(alpha = 0.6f * (1f - k)),
                        w * 0.035f * (1f + k),
                        Offset(bx + bw * 0.80f + wave * w * 0.01f, h * 0.30f - k * h * 0.22f)
                    )
                }
            }
            "B1" -> {
                val m1 = Path().apply {
                    moveTo(w * 0.04f, h * 0.88f); lineTo(w * 0.38f, h * 0.36f); lineTo(w * 0.72f, h * 0.88f); close()
                }
                drawPath(m1, Color(0xFF8D6E63))
                val m2 = Path().apply {
                    moveTo(w * 0.40f, h * 0.88f); lineTo(w * 0.68f, h * 0.50f); lineTo(w * 0.96f, h * 0.88f); close()
                }
                drawPath(m2, Color(0xFFA1887F))
                val snow = Path().apply {
                    moveTo(w * 0.38f, h * 0.36f); lineTo(w * 0.30f, h * 0.49f); lineTo(w * 0.46f, h * 0.49f); close()
                }
                drawPath(snow, Color.White)
                drawLine(Color(0xFF5D4037), Offset(w * 0.38f, h * 0.36f), Offset(w * 0.38f, h * 0.12f), strokeWidth = w * 0.02f)
                val fw = w * 0.26f
                val band = h * 0.045f
                val cols = listOf(Color.Black, Color(0xFFDD0000), Color(0xFFFFCE00))
                cols.forEachIndexed { i, c ->
                    val y = h * 0.12f + i * band
                    val dy = wave * h * 0.02f
                    val x0 = w * 0.38f
                    val path = Path().apply {
                        moveTo(x0, y)
                        quadraticBezierTo(x0 + fw / 2f, y + dy, x0 + fw, y)
                        lineTo(x0 + fw, y + band)
                        quadraticBezierTo(x0 + fw / 2f, y + band + dy, x0, y + band)
                        close()
                    }
                    drawPath(path, c)
                }
            }
            "B2" -> {
                val stars = listOf(Offset(w * 0.16f, h * 0.22f), Offset(w * 0.84f, h * 0.34f), Offset(w * 0.22f, h * 0.70f), Offset(w * 0.80f, h * 0.78f))
                stars.forEachIndexed { i, o ->
                    val a = if (i % 2 == 0) 0.4f + 0.6f * up else 1f - 0.6f * up
                    drawCircle(Color.White.copy(alpha = a), w * 0.025f, o)
                }
                translate(0f, wave * h * 0.03f) {
                    val fl = 0.8f + 0.2f * ((sin(p * 12f * PI.toFloat()) + 1f) / 2f)
                    val flame = Path().apply {
                        moveTo(w * 0.44f, h * 0.70f); lineTo(w * 0.5f, h * (0.70f + 0.20f * fl)); lineTo(w * 0.56f, h * 0.70f); close()
                    }
                    drawPath(flame, Color(0xFFFFB300))
                    val finL = Path().apply {
                        moveTo(w * 0.38f, h * 0.52f); lineTo(w * 0.26f, h * 0.74f); lineTo(w * 0.38f, h * 0.70f); close()
                    }
                    val finR = Path().apply {
                        moveTo(w * 0.62f, h * 0.52f); lineTo(w * 0.74f, h * 0.74f); lineTo(w * 0.62f, h * 0.70f); close()
                    }
                    drawPath(finL, Color(0xFFE53935))
                    drawPath(finR, Color(0xFFE53935))
                    val body = Path().apply {
                        moveTo(w * 0.5f, h * 0.14f)
                        quadraticBezierTo(w * 0.68f, h * 0.34f, w * 0.62f, h * 0.70f)
                        lineTo(w * 0.38f, h * 0.70f)
                        quadraticBezierTo(w * 0.32f, h * 0.34f, w * 0.5f, h * 0.14f)
                        close()
                    }
                    drawPath(body, Color(0xFFECEFF1))
                    drawCircle(Color(0xFF42A5F5), w * 0.07f, Offset(w * 0.5f, h * 0.40f))
                }
            }
            else -> {}
        }
    }
}
