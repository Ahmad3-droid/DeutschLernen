package com.deutschlernen

import android.content.Context
import kotlin.math.abs

/** قاموس يُبنى من ملفات assets (يكبر تلقائياً كلما أضفتَ كلمات). */
class Lexicon(ctx: Context) {
    val gender = HashMap<String, String>()
    val known = HashSet<String>()

    init {
        val word = Regex("[A-Za-zÄÖÜäöüß]+")
        val articles = setOf("der", "die", "das")
        (ctx.assets.list("") ?: emptyArray()).filter { it.endsWith(".txt") }.forEach { f ->
            ctx.assets.open(f).bufferedReader().readLines().forEach { line ->
                word.findAll(line).forEach { known.add(it.value.lowercase()) }
                val parts = line.substringBefore(";").trim().split(" ")
                if (parts.size == 2 && parts[0].lowercase() in articles)
                    gender[parts[1].lowercase()] = parts[0].lowercase()
            }
        }
    }
}

/** مدقق قواعد أساسي يعمل دون إنترنت. */
object OfflineChecker {
    private val word = Regex("[A-Za-zÄÖÜäöüß]+")
    private val TYPOS = mapOf(
        "vieleicht" to "vielleicht", "villeicht" to "vielleicht", "garnicht" to "gar nicht",
        "nähmlich" to "nämlich", "nehmlich" to "nämlich", "auser" to "außer", "ausser" to "außer",
        "strasse" to "Straße", "bischen" to "bisschen", "standart" to "Standard", "morgends" to "morgens",
        "intresse" to "Interesse", "eigendlich" to "eigentlich", "wirglich" to "wirklich",
        "endschuldigung" to "Entschuldigung", "vorallem" to "vor allem", "gewessen" to "gewesen",
        "wass" to "was", "halo" to "hallo", "danke schon" to "danke schön",
    )
    private val SEIN = mapOf("ich" to "bin", "du" to "bist", "er" to "ist", "es" to "ist", "wir" to "sind", "ihr" to "seid")
    private val HABEN = mapOf("ich" to "habe", "du" to "hast", "er" to "hat", "es" to "hat", "wir" to "haben", "ihr" to "habt")
    private val SEIN_FORMS = setOf("bin", "bist", "ist", "sind", "seid")
    private val HABEN_TO_SEIN = mapOf("habe" to "bin", "hast" to "bist", "hat" to "ist", "haben" to "sind", "habt" to "seid")
    private val MOTION = setOf("gegangen", "gekommen", "gefahren", "gewesen", "geblieben", "geflogen", "gelaufen", "gereist", "geschwommen")
    private val DETERMINERS = setOf("der","die","das","den","dem","des","ein","eine","einen","einem","einer","mein","meine","meinen","meinem","meiner","dein","deine","sein","seine","kein","keine","keinen","unser","unsere","ihre")
    private val QUESTION = setOf("wer", "was", "wo", "wann", "wie", "warum", "wieso", "welche", "welcher", "welches", "wohin", "woher")

    private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length)
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }

    fun check(text: String, lx: Lexicon): List<Issue> {
        val out = ArrayList<Issue>()
        val used = HashSet<Int>()
        val toks = word.findAll(text).toList()
        fun lw(i: Int) = toks[i].value.lowercase()
        fun adjacent(i: Int) = i + 1 < toks.size && text.substring(toks[i].range.last + 1, toks[i + 1].range.first).isBlank()
        fun sameSentence(i: Int, j: Int) = text.substring(toks[i].range.last + 1, toks[j].range.first).none { it in ".!?" }
        fun isStart(i: Int): Boolean {
            val b = text.substring(0, toks[i].range.first).trimEnd()
            return b.isEmpty() || b.last() in ".!?"
        }
        fun fx(i: Int, new: String) = if (isStart(i) || toks[i].value.first().isUpperCase()) cap(new) else new
        fun add(i: Int, msg: String, fix: String?, soft: Boolean = false) {
            if (used.add(toks[i].range.first)) out.add(Issue(toks[i].range.first, toks[i].value.length, msg, fix, soft))
        }

        // 1) الأداة مع جنس الاسم
        for (i in 0 until toks.size - 1) {
            if (!adjacent(i)) continue
            val a = lw(i)
            val g = lx.gender[lw(i + 1)] ?: continue
            val n = lw(i + 1)
            val right = when {
                a == "die" && g != "die" && !(n.endsWith("er") || n.endsWith("el") || n.endsWith("en")) -> g
                a == "das" && g != "das" -> g
                a == "der" && g == "das" -> g
                a == "ein" && g == "die" -> "eine"
                a == "eine" && g != "die" -> "ein"
                else -> null
            } ?: continue
            add(i, "الاسم «${toks[i + 1].value}» أداته $g، فاستخدم «$right»", fx(i, right))
        }

        // 2) تصريف sein / haben مع الضمير
        for (i in 0 until toks.size - 1) {
            if (!adjacent(i)) continue
            val p = lw(i); val t = lw(i + 1)
            val s = SEIN[p]; val h = HABEN[p]
            if (s != null && t in SEIN_FORMS && t != s)
                add(i + 1, "مع «${toks[i].value}» نستخدم «$s»", fx(i + 1, s))
            if (h != null && t in HABEN_TO_SEIN.keys && t != h)
                add(i + 1, "مع «${toks[i].value}» نستخدم «$h»", fx(i + 1, h))
        }

        // 3) أفعال الحركة تأخذ sein في الماضي
        for (i in toks.indices) {
            val s = HABEN_TO_SEIN[lw(i)] ?: continue
            for (j in i + 1..minOf(i + 4, toks.size - 1)) {
                if (!sameSentence(i, j)) break
                if (lw(j) in MOTION) {
                    add(i, "الفعل «${toks[j].value}» يأخذ sein في الماضي: «$s»", fx(i, s)); break
                }
            }
        }

        // 4) أخطاء إملائية شائعة
        for (i in toks.indices) TYPOS[lw(i)]?.let { add(i, "خطأ إملائي شائع", fx(i, it)) }

        // 5) الأحرف الكبيرة
        for (i in toks.indices) {
            val v = toks[i].value
            if (!v[0].isLowerCase()) continue
            if (isStart(i)) add(i, "الجملة تبدأ بحرف كبير", cap(v))
            else if (lx.gender.containsKey(lw(i)) && i > 0 && adjacent(i - 1) && lw(i - 1) in DETERMINERS) add(i, "الأسماء في الألمانية تُكتب بحرف كبير", cap(v))
        }

        // 6) علامة نهاية الجملة
        val trimmed = text.trimEnd()
        if (trimmed.isNotEmpty() && trimmed.last() !in ".!?" && toks.isNotEmpty()) {
            val q = lw(0) in QUESTION
            out.add(Issue(trimmed.length, 0, "الجملة تحتاج علامة في نهايتها", if (q) "?" else "."))
        }

        // 7) تلميح إملائي (احتمالي) اعتماداً على القاموس
        for (i in toks.indices) {
            val v = toks[i].value
            if (v.length < 5 || v[0].isUpperCase()) continue
            val l = v.lowercase()
            if (l in lx.known) continue
            val cand = lx.known.firstOrNull { c ->
                c.length >= 4 && c[0] == l[0] && abs(c.length - l.length) <= 1 &&
                    !c.startsWith(l) && !l.startsWith(c) && lev(c, l) <= 1
            }
            if (cand != null) add(i, "هل تقصد «$cand»؟ (قد تكون كلمتك صحيحة لكنها غير موجودة في قاموس التطبيق)", fx(i, cand), soft = true)
        }
        return out.sortedBy { it.offset }
    }
}

/** نسخة واحدة من القاموس تُحمَّل مرة واحدة في الخلفية. */
object Lexicons {
    @Volatile
    private var lx: Lexicon? = null

    fun get(ctx: Context): Lexicon =
        lx ?: synchronized(this) { lx ?: Lexicon(ctx.applicationContext).also { lx = it } }
}
