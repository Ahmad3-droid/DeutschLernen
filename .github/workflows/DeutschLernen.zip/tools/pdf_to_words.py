"""استخراج الكلمات من ملف PDF إلى ملف مستوى.
الاستخدام:  python tools/pdf_to_words.py book.pdf A1_1
يتطلب:      pip install pypdf
يقرأ أسطراً بصيغة  "Wort - ترجمة"  (أو – أو :) ويكتب
app/src/main/assets/words_A1_1.txt  بصيغة  ألماني;عربي;مثال
راجع الناتج يدوياً، فتنسيق كل PDF مختلف."""
import re, sys
from pypdf import PdfReader

pdf, code = sys.argv[1], sys.argv[2]
rows = []
for page in PdfReader(pdf).pages:
    for line in (page.extract_text() or "").splitlines():
        m = re.match(r"^\s*([A-Za-zÄÖÜäöüß][^-–:]{1,40}?)\s*[-–:]\s*(.+)$", line)
        if m:
            rows.append(f"{m.group(1).strip()};{m.group(2).strip()};")
out = f"app/src/main/assets/words_{code}.txt"
open(out, "w", encoding="utf-8").write("\n".join(rows) + "\n")
print(f"{len(rows)} words -> {out}")
